public class Author extends Person{
    private String publisher;
    public Author(String name,String publisher,int birthDate) {
        super(name, birthDate);
        this.publisher = publisher;
    }
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public String toString() {
        return this.getName()+" ";
    }
}
