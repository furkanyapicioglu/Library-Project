public class Book {
    private int id;
    private String title;
    private Author author;
    private boolean borrowed;
    public Book(int id,String title,Author author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }
    public Book(int id,String title) {
        this.id = id;
        this.title = title;
    }
    public boolean borrowed() {
        return borrowed=true;
    }
    public boolean isBorrowed() {
        if (borrowed) {
            return true;
        }
        else {
            return false;
          }
        }
    public boolean returned() {
        return borrowed = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }
    @Override
    public String toString() {
        return "Book name is "+this.getTitle()+" Author is "+this.getAuthor();
    }

    boolean contains(boolean borrowed) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
