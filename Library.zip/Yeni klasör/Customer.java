public class Customer extends Person{
    private String address = "-";
    private Book borrowedBook;
    private boolean borrowABook; 
    public Customer(String name,String birthPlace,int birthDate,String address) {
        super(name, birthPlace, birthPlace);
        this.address = address;
    }
    public Customer(String name,int birthDate,String address) {
        super(name,birthDate);
        this.address = address;
    }
    public Customer(String name,String address) {
        super(name);
        this.address = address;
    }
    public Customer(String name,int birthDate) {
        super(name,birthDate);
    }
    public String getAddress() {
        return address;     
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Book getBorrowedBook() {
        return borrowedBook;
    }

    public void setBorrowedBook(Book borrowedBook) {
        this.borrowedBook = borrowedBook;
    }

    public boolean isBorrowABook() {
        return borrowABook;
    }

    public void setBorrowABook(boolean borrowABook) {
        this.borrowABook = borrowABook;
    }
    @Override
    public String toString() {
        return "Name " + this.getName()+" Birth Date: "+this.getBirthDate()+" Birth Place: "+this.getBirthPlace() + "\n"+ "Address: "+this.getAddress();
    }
/*
    void setBorrowedBook(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setBorrowedBook(String title) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
*/
}