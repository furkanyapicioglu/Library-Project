import java.util.ArrayList;
public class Library {
    private String address;
    private ArrayList<Book> books;                  //i defined variables in here...
    private ArrayList<Customer> customers;
    
    public Library(String address) {
    this.address = address;
    this.books = new ArrayList<Book>();
    this.customers = new ArrayList<Customer>();
    }
    //printing hours which is same for every library.
    public static void printOpeningHours() {
        System.out.println("Libraries are open daily from 9 am to 5 pm.");
    }
    //printing addresses which is selected.
    public void printAddress() {
        System.out.println(getAddress());
    }   
    public boolean addBook(Book book) {
        if (book.getTitle().equals(book)) {
            return false;
        }
        else {
            this.books.add(book);
            return true;
        }
    }    
    public void addCustomer(Customer customer) {
        this.customers.add(customer);
    } 
    public void borrowBook(String bookName,String personName) {                 //in here: i defined borrowBook method(i really tried to not more than one
                                                                                //printing. but i could not but it works correct.
        books.forEach((Book book) -> {
            if (book.getTitle().equals(bookName)) {
                if(book.isBorrowed()) {
                    System.out.println("Sorry, this book is already borrowed");
                }
                else if (book.borrowed()) {
                    System.out.println(personName+ " successfully borrowed " + book.getTitle()+ ".");
                    for(Customer customer: customers) {
                        if (customer.getName().equals(personName)) {
                        customer.setBorrowedBook(book);
                        }  
                }
            }
            else if (!book.getTitle().equals(bookName)) {
                System.out.println("Sorry, this book is not in our catalog");
            }
        }
        });
    }
    public void returnBook(String personName) {
            for (Customer customer: customers) {                                    //same thing happening in here(printing more than one but works clear.
                if (customer.getName().equals(personName)) {
                    if (customer.getBorrowedBook() == null) {
//                        System.out.println(customer.getBorrowedBook().getTitle());
                        System.out.println("Sorry, " + personName + " did not barrow a book");
                        System.out.println(customer.getBorrowedBook());
                    }
                    else if(customer.getBorrowedBook() != null) {
                    System.out.println(personName +" successfully returned " + customer.getBorrowedBook().getTitle());
                    customer.setBorrowedBook(null);
                    System.out.println(customer.getBorrowedBook());
                    }
                
                           }
                else if(!customer.getName().equals(personName)) {
                    System.out.println("Sorry, "+ personName + " is not a customer.");
                }
            }
    }
    public void printAvailableBooks() {
        if(books.isEmpty()){
			System.out.println("No book in catalog.");
		}
        for(Book book:this.books){
			System.out.println(book.toString());
		}
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public ArrayList<Book> getBooks() {
        return books;
    }
    public void setBooks(ArrayList<Book> books) {
        this.books = books;
    }
    public ArrayList<Customer> getCustomers() {
        return customers;
    }
    public void setCustomers(ArrayList<Customer> customers) {
        this.customers = customers;
    }
}