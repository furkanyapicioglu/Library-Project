public class Person {
    private String name;
    private String birthDate= "-";
    private String birthPlace= "-";
    public Person(String name,String birthDate,String birthPlace) {
        this.name = name;
        this.birthDate = String.valueOf(birthDate);
        this.birthPlace = birthPlace;
    }
    public Person(String name, int birthdate) {
        this.name = name;
        this.birthDate = String.valueOf(birthdate);
    }
    public Person(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }
    @Override
    public String toString() {
        return this.getName()+" "+this.getBirthDate()+" "+this.getBirthPlace();
    }
}
